<?php 
?>
<footer>
            Disclaimer: The information in this site is not real.
</footer>
 