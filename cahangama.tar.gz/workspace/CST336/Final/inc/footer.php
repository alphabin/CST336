      <footer>
        Team 9 | Final Project<br>
        CST336-40 Internet Programming 2018&copy; <br/>
        <strong>Disclaimer:</strong> The information in this webpage is ficticious.  It is used for academic purposes only.
        <figure><a href="https://csumb.edu/"><img src="img/csumb_logo.png" alt="CSUMB logo"/></a></figure>
      </footer>  
      </div>
    </body>
</html>