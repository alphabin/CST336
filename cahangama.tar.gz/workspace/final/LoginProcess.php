     <?php
        session_start();
        include 'dbConnection.php';
        $conn = getDatabaseConnection("finalExam");
        
        function checkPassword()
        {
            global $conn;
            
            $username = $_POST['username'];
            $password = sha1($_POST['password']);
    
            //echo $password;
            $sql = "SELECT *
                    FROM fe_login
                    WHERE username = :username";
                    
            $np = array();
            $np[":username"] = $username;
            
            
            
            echo "inside function";
            echo $username."<br>";
            echo $password;
            $stmt = $conn->prepare($sql);
            $stmt->execute($np);
            $record = $stmt->fetch(PDO::FETCH_ASSOC); // expecting one single record
            
            echo $record;
            
            if(empty($record))
            {
                $_SESSION['incorrect'] = true;
               
             
                header("Location:Program1.php");
                 
            }
            else{
                //echo $record['firstName'] . " " . $record['lastName'];
                $_SESSION['incorrect'] = false;
               

               $passwordCorrrect = false;
               $getAttempts = 0;
               
               if($record['password'] == $password)
               {
                  $passwordCorrrect = true;
               }
               
               
               $getAttempts = intval($record['failedAttempts']);
               
               
               echo "Number of Trys Original : ".$getAttempts ."<br>";
                
               if($passwordCorrrect == false)
                {
                        $getAttempts = $getAttempts+1;
                }
                
               echo "Number of Trys After : ".$getAttempts . "<br>";
              
               if($getAttempts > 0)
               {
     
                   
                $sql = 
                "UPDATE 
                fe_login
                SET failedAttempts = :attempt
                 WHERE username = :username";
                
                $np = array();
                
                $np[":attempt"] = $getAttempts;
                $np[":username"] = $username;
  
                $stmt = $conn->prepare($sql);
                $stmt->execute($np);
                
                if($getAttempts == 3)
                {
                       
                    $sql = "REPLACE INTO fe_lock
                    (studentId)
                    VALUES(:studentId)";
                    
                    $np = array();
                    $np[':studentId'] = $record['studentId'];
                    $stmt = $conn->prepare($sql);
                    $stmt->execute($np);
                    $passwordCorrrect = false;
                   
                }
                
                if($getAttempts > 3)
                {
                   $passwordCorrrect = false; 
                }
                
               if($passwordCorrrect == false)
               {
                 header("Location:Program1.php");
               }
            
              }
               if($passwordCorrrect == true)
               {
                 $_SESSION['userName'] =  $username;
                 
                $sql = 
                "UPDATE 
                fe_login
                SET failedAttempts = :attempt
                 WHERE username = :username";
                
                $np = array();
                
                $np[":attempt"] = 0;
                $np[":username"] = $username;
                
                $stmt = $conn->prepare($sql);
                $stmt->execute($np);
                
                 header("Location:welcome.php");
                
               }
                
            }
        }
        
        echo "welcome";
        
        checkPassword();
        
    ?>
        