<?php
       
       include 'dbConnection.php';
       
       $conn = getDatabaseConnection("finalExam");
       
       function getFeTable(){
        global $conn;
        $sql = "SELECT studentId,username,daysLeftPwdChange,failedAttempts FROM `fe_login`";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($records as $record) {
            echo "<tr><td>".$record["studentId"]."</td><td>" . $record["username"] ."</td><td>". $record["failedAttempts"]."</td><td>".$record["daysLeftPwdChange"]."</td></tr>";
        }
           
       }
       
       function getLockedTableId()
       {
                global $conn;
                $sql = "SELECT studentId FROM `fe_lock`";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($records as $record) {
            echo " ".$record["studentId"]." ";
        }
       }
       
       function makeTableOfRecords()
        {
           echo "<table>
			    <tr><th>studentId</th><th>username</th><th>failedAttempts</th><th>daysLeftPwdChange</th></tr>";
	            getFeTable();
	       echo "</table>";
            
        }
        
       function getLockedStudentRecords(){
            echo "Locked Student Ids:";
            getLockedTableId();
        }
        
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Program 1</title>
	    <script src="https://code.jquery.com/jquery-3.3.1.js"  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="  crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
		<link href='css/styles.css' rel='stylesheet'>
		<script>
			$(document).ready(
			    function(){
                 $('[data-toggle="tooltip"]').tooltip(); 
                 
                 $("body").click(function() {
                 	 if(!$('#username').val()){
                 	 	 $("#pwd_change").html("");
                         $("#lock_status").html("");
                 	 }
                     if($('#username').val())
                     {
                            var postForm = { //Fetch form data
                                'userName': $('#username').val()
                        };
    					 //Do the Ajax Call
                        $.ajax({
                          type: "POST",
                          url: "postRequest.php",
                          data: postForm,
                          dataType: 'json',
                          success: function(successResult){
                               if (!successResult) {
                                    $("#pwd_change").html("");
                                    $("#lock_status").html("");
                               }
                               else{
                                   if(successResult.dayLeft.daysLeftPwdChange == 0)
                                   {
                                     $("#pwd_change").html("You must change your password NOW");
                                     $("#pwd_change").css("color", "red");
                                   }
                                   if(successResult.dayLeft.daysLeftPwdChange > 0)
                                   {
                                     $("#pwd_change").html("You have "+successResult.dayLeft.daysLeftPwdChange+" days to change your password");
                                     if(successResult.dayLeft.daysLeftPwdChange > 0 && successResult.dayLeft.daysLeftPwdChange <= 15)
                                     {
                                         $("#pwd_change").css("color", "red");
                                     }
                                     else
                                     {
                                         $("#pwd_change").css("color", "black");
                                     }
                                   }
                                  
                                  if(successResult.dayLeft.failedAttempts >= 3)
                                   {
                                     $("#lock_status").html("This account is locked!");
                                     $("#lock_status").css("color", "red");
                                   }
                                   
                               }
                          }
           
                        });
                                                 
                     }
				  });
				               
            });
		</script>

	</head>
	<body>

		<main>
			<div class="jumbotron">
				<h1> Login </h1>
			</div>
			
			<form action="LoginProcess.php" method="post">
				<input id='username' name="username" type='text' placeholder='username' />
				<a href="#" data-toggle="tooltip" title="After entering username, display message based on the value of 'daysLeftPwdChange'">
				<img src='../img/info.png' width='20'></a>
				<br />
				<br />
				<input id='password' name="password" type='password' placeholder='password' />
				<a href="#" data-toggle="tooltip" title="Passwords are the same as usernames">
				<img src='../img/info.png' width='20'></a>

				<br />
				<br />
				 <button type="submit" class="btn btn-primary" name="login">Login</button>  
				<br />
				<br />
			</form>
			<div id="errorMessages">
				<span id='pwd_change'></span>
				<br />
				<span id='lock_status'></span>
				<br />
			</div>
			<br />
			<br />
			
			<h5>"fe_login" Table Data
				<a href="#" data-toggle="tooltip" title="The display of the table data is updated only when refreshing the page">
				<img src='../img/info.png' width='20'></a>
	
			</h5>
                <?= makeTableOfRecords()?>
            
					
			    
			 <br>
		         <?= getLockedStudentRecords()?>
		</main>

		<br />
		<br />
		<br />

		<table border=1 width="600">
			<tr>
				<th>#</th><th>Task Description</th><th>Points</th>
			</tr>
			<tr style="background-color:#99E999">
				<td>1</td>
				<td class="leftAligned">The data from the fe_login table is displayed below the Login form (when loading the page) </td>
				<td width="20" align="center">5</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>2</td>
				<td class="leftAligned">The locked Student ids (from the fe_lock table) are displayed when loading the page </td>
				<td width="20" align="center">5</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>3</td>
				<td class="leftAligned">The welcome.php file is shown when the user enters the right credentials AND the account is NOT locked. The username is displayed in the Welcome message.</td>
				<td width="20" align="center">5</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>4</td>
				<td class="leftAligned">After typing the username, the number of days left to change the password is shown in red if the value of daysLeftPwdChange is between 1 and 15</td>
				<td width="20" align="center">10</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>5</td>
				<td class="leftAligned">After typing the username, "You must change your Password NOW" is displayed in red if the value of daysLeftPwdChange is 0</td>
				<td width="20" align="center">10</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>6</td>
				<td class="leftAligned">If the account is NOT locked, the &quot;failedAttempts&quot; field is reset to 0 when the user enters the right credentials.</td>
				<td width="20" align="center">15</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>7</td>
				<td class="leftAligned">The &quot;failedAttempts&quot; field is increased by 1 when entering the wrong password</td>
				<td width="20" align="center">15</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>8</td>
				<td class="leftAligned">A new record is inserted in the &quot;fe_lock&quot; table when the &quot;failedAttempts&quot; field has a value of 3.</td>
				<td width="20" align="center">15</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>9</td>
				<td class="leftAligned">The message &quot;This account is locked&quot; is displayed when the account is locked and entering the right username/password</td>
				<td width="20" align="center">10</td>
			</tr>
			<tr style="background-color:#99E999">
				<td>10</td>
				<td class="leftAligned">This rubric is properly included AND UPDATED</td>
				<td width="20" align="center">2</td>
			</tr>
			<tr>
				<td></td>
				<td>T O T A L </td>
				<td width="20" align="center"><strong>92</strong></td>
			</tr>
		</table>
	</body>
</html>