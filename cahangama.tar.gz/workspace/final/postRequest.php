<?php
        include 'dbConnection.php';
        $conn = getDatabaseConnection("finalExam");
        
        function respondToLockOut()
        {
            $form_data = array();
            $userName = $_POST['userName'];
            
            if (empty($_POST['userName'])) {
              json_encode($form_data);
            }
            else
            {

             global $conn;
             $sql = "SELECT username,daysLeftPwdChange,failedAttempts FROM `fe_login` WHERE username = '".$userName."'";
             $stmt = $conn->prepare($sql);
             $stmt->execute();
             $record = $stmt->fetch(PDO::FETCH_ASSOC);
             $form_data['dayLeft'] = $record;
             
            }
            echo json_encode($form_data);
        }
        
       respondToLockOut();
?>