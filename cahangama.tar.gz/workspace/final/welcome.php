<?php

    session_start();
    echo "Welcome User:". $_SESSION['userName'];
?>