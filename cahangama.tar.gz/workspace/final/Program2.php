<?php 
    function DisplayLocked()
    {
        include 'dbConnection.php';
       
        $conn = getDatabaseConnection("finalExam");
       
        $sql = "SELECT studentId FROM `fe_lock`";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($records as $record) {
             $sql = "SELECT studentId,username,daysLeftPwdChange,failedAttempts FROM `fe_login` WHERE studentId =".$record["studentId"];
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $recordin = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "<tr><td>" . $recordin["username"] ."</td><td>". $recordin["failedAttempts"]."</td> <td> <button class='unlockBtn' id='". $recordin["studentId"]."' >Unlock </button></tr>";
        }
           
      
        
    }
?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>

		<script src="https://code.jquery.com/jquery-2.2.3.js" integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="  crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
		<link href='../program1/css/styles.css' rel='stylesheet'>
		<script src='js/jquery.min.js'></script>

	</head>
	<body>
		<div class="jumbotron">
			<h1> Unlocking Accounts </h1>
		</div>
		<center>
			<br>

			<table border=1>

				<tr>
					<th> Username </th>
					<th> Failed Attempts </th>
					<th> Action </th>
				</tr>

				    <?= DisplayLocked()	?>		
				</table>
			        

		</center>

		<br/>
		<br/>
		<table border="1" width="600" id="rubric">
			<tbody>
				<tr>
					<th>#</th><th>Task Description</th><th>Points</th>
				</tr>
				<tr style="background-color:#99E999">
					<td>1</td>
					<td>The list of locked accounts is properly displayed, including the username and failed attempts.</td>
					<td width="20" align="center">15</td>
				</tr>
	
			
				<tr style="background-color:#99E999">
					<td>5</td>
					<td>This rubric is properly included AND UPDATED</td>
					<td width="20" align="center">2</td>
				</tr>
				<tr>
					<td></td>
					<td>T O T A L </td>
					<td width="20" align="center">&nbsp;</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>