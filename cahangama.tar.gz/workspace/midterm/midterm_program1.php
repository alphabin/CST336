<?php
    /*arrays of men and female heros*/
    $women = array("blossom", "gamora", "rey","wonderwoman","xena");
    $men =  array("goku", "leo", "mario","monte","spiderman");
    
    session_start();
    
    if(!isset($_SESSION['searchHistory']))
    {
        $_SESSION['searchHistory'] = array();
    }
    
    function inValue(array $array, $key) {
        return isset($array[$key]) ? true : false;
    }
    
    
    function displaySearchResult()
    {
        global  $men,$women;
            
        $teamSize = $_GET['inputTeamSize'];
        $teamGender = $_GET['gender'];
        $displayOrder = $_GET['aOrder'];
        $displayImages = $_GET['displayImages'];
        
        $arryOfResult = array();
        
        $errorMessage = "";
        $resultHTML ="";
        
        //Validation
        if(isset($_GET['inputTeamSize']))
        {
            if(is_numeric($teamSize))
            {
               $teamSize = intval($teamSize);
               if(isset($_GET['gender']))
                {
                   $teamGender = $_GET['gender'];
                       
                if(isset($_GET['aOrder']))
                {
                    $displayOrder = $_GET['aOrder'];
                }
                else{
                    return "<h2>Has Not Selected Display Order</h2>";
                }
                }
                else
                {
                    return "<h2>Has Not Selected a Gender</h2>";
                }
            }
            else
            {
                return "<h2>Not a Valid Number</h2>";
            }
        }
        
        
        
        for ($x = 1; $x <=  $teamSize; $x++) 
        {
            //echo $x;
            if($teamGender == 'male')
            {
            
             $randomIndex = 0;
               do
                {
                    $randomIndex = rand(0,4);
                }while(in_array($men[$randomIndex],$arryOfResult));
                
                $arryOfResult[] = $men[$randomIndex];
            }
            else if($teamGender == 'female')
            {
                 $randomIndex = 0;
               do
                {
                    $randomIndex = rand(0,4);
                }while(in_array($women[$randomIndex],$arryOfResult));
                
                $arryOfResult[] = $women[$randomIndex];
            }
            else if($teamGender == 'coed')
            {
              $chance =rand(0,1) ;           
              if($chance == 1)
              {
                    $randomIndex = 0;
                       do
                        {
                            $randomIndex = rand(0,4);
                        }while(in_array($men[$randomIndex],$arryOfResult));
                        
                        $arryOfResult[] = $men[$randomIndex];
              }
              else
              {
                     $randomIndex = 0;
               do
                {
                    $randomIndex = rand(0,4);
                }while(in_array($women[$randomIndex],$arryOfResult));
                
                    $arryOfResult[] = $women[$randomIndex];
                }
            }
        }
        
       
        if(count($arryOfResult)>=1)
            {
                if($displayOrder == "AtoZ")
                    sort($arryOfResult);
                else
                {
                    
                    rsort($arryOfResult);
                }
                
              array_push($_SESSION['searchHistory'], $arryOfResult);
              return $arryOfResult;
            }
        else
            {
                  return "";
            }
        
    }
   
?>



<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Bangers|Kumar+One+Outline" rel="stylesheet">
    
        <style type="text/css">
            @import url("css/styles.css");
        </style>
        
    </head>
    <body>
        <div class="jumbotron jumbotron-fluid">
          <div class="container">
            <h1 class="display-4 centered">Super Hero  Generator</h1>
          </div>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-lg-12  col-sm-12  centered">
                    <form action="#"> 
                        <div class="form-group row">
                            <label for="inputTeamSize" class="col-sm-3 col-form-label">Team Size </label>
                            <div class="col-sm-1">
                              <input type="text" class="form-control"  name="inputTeamSize" id="inputTeamSize">
                            </div>  
                        </div>
                        
                        <div class="form-group row">
                            <label for="gender" class="col-sm-3 col-form-label">Team Type </label>
                            <div class="col-sm-4">
                                  <input type="radio" name="gender" value="male"> Male
                                  <input type="radio" name="gender" value="female"> Female
                                  <input type="radio" name="gender" value="coed"> Coed
                            </div>  
                        </div>
                        
                        <div class="form-group row">
                            <label for="aOrder" class="col-sm-3 col-form-label"> Display Team Order </label>
                            <div class="col-sm-4">
                                  <input type="radio" name="aOrder" value="AtoZ"> A-Z
                                  <input type="radio" name="aOrder" value="ZtoA"> Z-A
                            </div>  
                        </div>
                        
                         <div class="form-group row">
                            <div class="col-sm-4">
                                     <input type="checkbox" name="displayImages" value="true"> Display Images 
                            </div>  
                        </div>
                          <button type="submit" class="btn btn-primary mb-2">Generate Team</button>
                    </form>
                     <form action="team_history.php"> 
                          <button type="submit" class="btn btn-primary mb-2">Show Team Generation History</button>
                    </form>
                </div>
            </div>
            
            <div class="row">
                <?php
                    $arrarResults = (displaySearchResult());
                ?>
                
                <?php
                if 
                    (count($arrarResults) >= 1) { ?>
                      <div>
                          <table border="1">
                            <?php
                            
                            $c= count($arrarResults);
                            $displayImages = $_GET['displayImages'];
                            
                            if(is_array($arrarResults))
                            {
                                echo "<h3> ";
                                 echo "Gender ";
                                 echo $_GET['gender'];
                                echo "</h3>";
                              
                               echo "<h3> ";
                                 echo "Count ";
                                 echo $_GET['inputTeamSize'];
                                echo "</h3>";
                              
                            for( $i = 0; $i<$c;$i+=2)
                            {
                                echo "<tr>"; 
                                if($arrarResults[$i] != null)
                                {
                               
                                        echo "<td>";
                                            echo $arrarResults[$i];
                                            if($displayImages == 'true')
                                                echo '<img src="img/'.$arrarResults[$i].'.png">';
                                        echo "</td>";
                              
                                }
                                if($arrarResults[$i+1] != null)
                                {
                               
                                          echo "<td>";
                                            echo $arrarResults[$i+1];
                                            if($displayImages == 'true')
                                                echo '<img src="img/'.$arrarResults[$i+1].'.png">';
                                        echo "</td>";
                              
                                }
                                echo "</tr>";
                            }
                            }
                             ?>
                          </table>
                      </div>
                <?php }
                else
                {
                        echo displaySearchResult();
                }
                ?>
            </div>
            
            <table border="1" width="600">
            <tbody><tr><th>#</th><th>Task Description</th><th>Points</th></tr>
            <tr style="background-color:#99E999">
              <td>1</td>
              <td>The page includes the form elements as the Program Sample: checkbox, radio buttons, etc.</td>
              <td width="20" align="center">5</td>
            </tr>
            <tr style="background-color:#99E999">
              <td>2</td>
              <td>Error is displayed if team gender is not submitted.</td>
              <td width="20" align="center">5</td>
            </tr> 
            <tr style="background-color:#99E999">
              <td>3</td>
              <td>Error is displayed if team size is less than 1 or left blank </td>
              <td align="center">5</td>
            </tr>    
           <tr style="background-color:#99E999">
              <td>4</td>
              <td>Error is displayed if team size is greater than 5 AND gender is not coed, or if size is greater than 10 AND gender is coed </td>
              <td align="center">5</td>
            </tr>
            <tr style="background-color:#99E999">
              <td>5</td>
              <td>Header is displayed with info submitted (team size and gender) </td>
              <td align="center">5</td>
            </tr>    
        	<tr style="background-color:#99E999">
              <td>6</td>
              <td>A random NOT coed team is displayed properly when selecting Male or Female as gender </td>
              <td align="center">15</td>
            </tr> 
           	<tr style="background-color:#99E999">
              <td>7</td>
              <td>If selecting "coed" as gender, there is at least one male and one female team member </td>
              <td align="center">15</td>
            </tr>  
            <tr style="background-color:#99E999">
              <td>8</td>
              <td>The names are ordered alphabetically as chosen by the user (asc/desc)</td>
              <td align="center">10</td>
            </tr>
            <tr style="background-color:#99E999">
              <td>9</td>
              <td>Team member's images are displayed if corresponding checkbox is checked</td>
              <td align="center">10</td>
            </tr>       
            <tr style="background-color:#99E999">
              <td>10</td>
              <td>Team members are displayed in a two-column table</td>
              <td align="center">15</td>
            </tr>  
            <tr style="background-color:#99E999">
              <td>11</td>
              <td>A second form allows users to see the history of generated teams</td>
              <td align="center">15</td>
            </tr>  
            <tr style="background-color:#99E999">
              <td>12</td>
              <td>The web page uses Bootstrap and has a nice look. </td>
              <td align="center">5</td>
            </tr>        
           <tr style="background-color:#99E999">
              <td>13</td>
              <td>This rubric is properly included AND UPDATED (BONUS)</td>
              <td width="20" align="center">2</td>
            </tr>   
             <tr>
              <td></td>
              <td>T O T A L </td>
              <td width="20" align="center"><b></b></td>
            </tr> 
          </tbody></table>
            
        </div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        </body>
</html>