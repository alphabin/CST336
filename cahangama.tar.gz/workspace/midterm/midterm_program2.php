<?php 
    include 'dbConnection.php';
    
    $conn = getDatabaseConnection("midterm"); //Starts the Db connection

    function displaySearchResultsEinstein(){
        global $conn;
        
        
            
            echo "<h3>Einstein: </h3>"; 
            
            $namedParameters = array();
            
            $sql = "SELECT * FROM q_quotes WHERE 1";
            
             
            $sql .=  " AND author LIKE :Name";
                 $namedParameters[":Name"] = "%" . "Albert Einstein" . "%"; //Like
           
            

            
             $stmt = $conn->prepare($sql);
             $stmt->execute($namedParameters);
             $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
         
            foreach ($records as $record) {
 
                 echo  $record["author"] . " " . $record["quote"]. "<br /><br />";
            }
      
        
    }
    
     function displaySearchResultsLife(){
        global $conn;
        
        
            echo "<h3>Life: </h3>"; 
            
            $namedParameters = array();
            
            $sql = "SELECT * FROM q_quotes WHERE 1";
            
             
            $sql .=  " AND quote LIKE :Name";
                 $namedParameters[":Name"] = "%" . "Life" . "%"; //Like
           
            

            
             $stmt = $conn->prepare($sql);
             $stmt->execute($namedParameters);
             $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
         
            foreach ($records as $record) {
 
                 echo  $record["author"] . " " . $record["quote"]. "<br /><br />";
            }
      
        
    }

     function displayAll(){
        global $conn;
        
        
            echo "<h3>All sorted </h3>"; 
            
            $namedParameters = array();
            
            $sql = "SELECT * FROM `q_quotes` ORDER BY :Name";
            
            $namedParameters[":Name"] = 'quote';
           
            

            
             $stmt = $conn->prepare($sql);
             $stmt->execute($namedParameters);
             $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
         
            foreach ($records as $record) {
 
                 echo  $record["author"] . " " . $record["quote"]. "<br /><br />";
            }
      
        
    }

    displaySearchResultsEinstein();
    
    displaySearchResultsLife();
    
    displayAll();
 
?>